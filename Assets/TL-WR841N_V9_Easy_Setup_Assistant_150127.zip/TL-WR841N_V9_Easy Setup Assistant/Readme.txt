TP-LINK Products Disk
P/N: CD226A4


Introduction:

1. Please select the right software and User Guide for each product. 

2. New versions of the Driver or User Guide may be released.
   Please pay attention to our website (http://www.tp-link.com) for the new versions.

3. To view the User Guide on this disk, please have Adobe Acrobat Reader 5.0 or later installed on your PC. 
   Adobe Acrobat Reader is a product of Adobe Systems Incorporated (http://www.adobe.com).

4. For help with the installation or operation of TP-LINK products, please contact us.
   Tel: +86 755 26504400
   E-mail: support@tp-link.com


Directory/File PATH				Model No. and Version		Description                   
=======================================================================================================================
<CD226A4>
|
+---Autorun.exe									Autorun program
| 
+---Readme.txt									This file      
|
+---Release.txt									CD release note
|
+---EasySetupAssistant							        Easy Setup Assistant Program
|   |  
|   \---EasySetupAssistant.exe						        Easy Setup Assistant for TL-WR841N/TL-WR841ND
|   
\---User Guide                           					                
    |
    \---TL-WR841N_841ND User Guide						TL-WR841N 9.0 /TL-WR841ND 9.0

========================================================================================================================                                                 